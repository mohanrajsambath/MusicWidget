package com.androidtask.musicwidget.activities;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FilterQueryProvider;
import android.widget.ListView;
import android.widget.SearchView;



import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;

import com.androidtask.musicwidget.MusicWidget;
import com.androidtask.musicwidget.R;
import com.androidtask.musicwidget.backend.SongListAdapter;
import com.androidtask.musicwidget.backend.SongListLoader;
import com.androidtask.musicwidget.model.Song;
import com.androidtask.musicwidget.service.MusicService;

public class SongListActivity extends AppCompatActivity {
    private SongListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getResources().getString(R.string.title_activity_song_list));
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);


        ListView list = (ListView) findViewById(R.id.listView);
        Cursor listCursor = SongListLoader.getInstance(this).getCursor();
        adapter = new SongListAdapter(this, listCursor);
        adapter.setFilterQueryProvider(new FilterQueryProvider() {
            @Override
            public Cursor runQuery(CharSequence constraint) {
                return SongListLoader.getInstance(SongListActivity.this).getFilteredCursor(constraint);
            }
        });

        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Song song = ((SongListAdapter)parent.getAdapter()).getSong(position);
                Log.i("SongListactivity click", song.toString());
                Intent serviceIntent = new Intent(SongListActivity.this, MusicService.class);
                serviceIntent.setAction(MusicWidget.ACTION_JUMP_TO);
                serviceIntent.putExtra("song", song);
                SongListActivity.this.startService(serviceIntent);
                finish();
            }
        });
    }





    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
    }


}
